import { useMemo } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import { nanoid } from "nanoid";

import i18n from "@/i18n";

export type ApiCallFormat = "openai" | "gemini";
export type ModelCapability = "image" | "video" | "text" | "audio";
export type ReasoningEffort = "auto" | "low" | "medium" | "high" | "xhigh";

export type ChannelModel = {
    name: string;
    capability: ModelCapability;
    script?: string;
};

export type ModelChannel = {
    id: string;
    name: string;
    baseUrl: string;
    apiKey: string;
    apiFormat: ApiCallFormat;
    models: ChannelModel[];
};

export type AiConfig = {
    channelMode: "remote" | "local";
    baseUrl: string;
    apiKey: string;
    apiFormat: ApiCallFormat;
    channels: ModelChannel[];
    model: string;
    imageModel: string;
    videoModel: string;
    textModel: string;
    audioModel: string;
    audioVoice: string;
    audioFormat: string;
    audioSpeed: string;
    audioInstructions: string;
    videoSeconds: string;
    vquality: string;
    videoGenerateAudio: string;
    videoWatermark: string;
    systemPrompt: string;
    reasoningEffort: ReasoningEffort;
    models: string[];
    quality: string;
    size: string;
    background: string;
    count: string;
    canvasImageCount: string;
};

export type WebdavSyncConfig = {
    url: string;
    username: string;
    password: string;
    directory: string;
    lastSyncedAt: string;
};
export type ConfigTabKey = "channels" | "preferences" | "prompt-sources" | "webdav" | "local-storage";

export const CONFIG_STORE_KEY = "infinite-canvas:ai_config_store";
const CHANNEL_MODEL_SEPARATOR = "::";
const LOCAL_OPENAI_BASE_URL = "http://localhost:18080";
const PUBLIC_OPENAI_BASE_URL = "https://api.cc2.cx";
const GEMINI_BASE_URL = "https://generativelanguage.googleapis.com";

/** Display labels for AutoDL workflows. Values remain canonical IDs for API requests. */
export const MODEL_DISPLAY_NAMES: Record<string, string> = {
    minimax_h3_z0903: "H3六图三音频生视频（高质量音画融合）",
    minimax_h3_z0902: "H3六图生视频（多图一致性创作）",
    minimax_h3_z0901: "H3文生视频（高质量创意直出）",
    minimax_h3_zm_u24: "H3多图多音频生视频（升级画质）",
    minimax_h3_zm_u08: "H3多图多音频生视频（高速版）",
    minimax_h3_b99_002: "H3首尾帧生成视频",
    minimax_h3_b99_001: "H3文生视频",
    minimax_h3_b99_003_12s: "H3多图生视频12秒",
    "wan2.2animate-v4-motion_retargeting": "动作迁移",
    minimax_h3_image_audio_to_video_v2_15s: "H3多图多音频生视频15秒",
    minimax_h3_lightx2v_v5_15s: "H3多图生视频15秒",
    minimax_h3_image_audio_to_video_v2: "H3多图多音频生视频",
    minimax_h3_image_audio_to_video: "H3图生视频-音频同步（自动对口型）",
    minimax_h3_lightx2v_v5: "H3多图参考生视频",
    minimax_h3_lightx2v_no_pic: "H3文生视频",
    minimax_h3_lightx2v: "H3首尾帧生成视频",
    "indextts2-v1": "IndexTTS 2语音合成",
};

// API requests must always use the canonical workflow ID. The UI can show a
// Chinese label, but persisted/legacy configs may contain that label directly.
// Only unambiguous labels are reverse-mapped; duplicate labels cannot safely
// identify one workflow and are therefore left unchanged.
const MODEL_API_NAMES: Record<string, string> = Object.entries(MODEL_DISPLAY_NAMES).reduce((result, [id, label]) => {
    if (Object.values(MODEL_DISPLAY_NAMES).filter((value) => value === label).length === 1) result[label] = id;
    return result;
}, {} as Record<string, string>);

function defaultOpenAiBaseUrl() {
    if (typeof window === "undefined") return LOCAL_OPENAI_BASE_URL;
    if (import.meta.env.DEV) return LOCAL_OPENAI_BASE_URL;
    return ["localhost", "127.0.0.1", "0.0.0.0", "::1"].includes(window.location.hostname.toLowerCase()) ? LOCAL_OPENAI_BASE_URL : PUBLIC_OPENAI_BASE_URL;
}

const OPENAI_BASE_URL = defaultOpenAiBaseUrl();

export const defaultConfig: AiConfig = {
    channelMode: "local",
    baseUrl: OPENAI_BASE_URL,
    apiKey: "",
    apiFormat: "openai",
    channels: [
        {
            id: "default",
            name: i18n.t("config.channels.defaultName"),
            baseUrl: OPENAI_BASE_URL,
            apiKey: "",
            apiFormat: "openai",
            models: [
                { name: "gpt-image-2", capability: "image" },
                { name: "minimax_h3_z0901", capability: "video" },
                { name: "minimax_h3_z0902", capability: "video" },
                { name: "minimax_h3_z0903", capability: "video" },
                { name: "minimax_h3_zm_u24", capability: "video" },
                { name: "minimax_h3_zm_u08", capability: "video" },
                { name: "minimax_h3_b99_001", capability: "video" },
                { name: "minimax_h3_b99_002", capability: "video" },
                { name: "minimax_h3_b99_003_12s", capability: "video" },
                { name: "minimax_h3_image_audio_to_video_v2_15s", capability: "video" },
                { name: "minimax_h3_lightx2v_v5_15s", capability: "video" },
                { name: "minimax_h3_image_audio_to_video_v2", capability: "video" },
                { name: "minimax_h3_image_audio_to_video", capability: "video" },
                { name: "minimax_h3_lightx2v_v5", capability: "video" },
                { name: "minimax_h3_lightx2v_no_pic", capability: "video" },
                { name: "minimax_h3_lightx2v", capability: "video" },
                { name: "indextts2-v1", capability: "audio" },
                { name: "wan2.2animate-v4-motion_retargeting", capability: "video" },
                { name: "seedance2.0-900-720p", capability: "video" },
                { name: "veo-3.1", capability: "video" },
                { name: "grok-imagine-video-1.5", capability: "video" },
                { name: "video-v3", capability: "video" },
                { name: "gpt-5.6-sol", capability: "text" },
                { name: "gpt-4o-mini-tts", capability: "audio" },
            ],
        },
    ],
    model: "default::gpt-image-2",
    imageModel: "default::gpt-image-2",
    videoModel: "default::seedance2.0-900-720p",
    textModel: "default::gpt-5.6-sol",
    audioModel: "default::gpt-4o-mini-tts",
    audioVoice: "alloy",
    audioFormat: "mp3",
    audioSpeed: "1",
    audioInstructions: "",
    videoSeconds: "10",
    vquality: "720",
    videoGenerateAudio: "true",
    videoWatermark: "false",
    systemPrompt: "",
    reasoningEffort: "auto",
    models: ["default::gpt-image-2", "default::minimax_h3_z0901", "default::minimax_h3_z0902", "default::minimax_h3_z0903", "default::minimax_h3_zm_u24", "default::minimax_h3_zm_u08", "default::minimax_h3_b99_001", "default::minimax_h3_b99_002", "default::minimax_h3_b99_003_12s", "default::minimax_h3_image_audio_to_video_v2_15s", "default::minimax_h3_lightx2v_v5_15s", "default::minimax_h3_image_audio_to_video_v2", "default::minimax_h3_image_audio_to_video", "default::minimax_h3_lightx2v_v5", "default::minimax_h3_lightx2v_no_pic", "default::minimax_h3_lightx2v", "default::indextts2-v1", "default::wan2.2animate-v4-motion_retargeting", "default::seedance2.0-900-720p", "default::veo-3.1", "default::grok-imagine-video-1.5", "default::video-v3", "default::gpt-5.6-sol", "default::gpt-4o-mini-tts"],
    quality: "auto",
    size: "1:1",
    background: "",
    count: "1",
    canvasImageCount: "3",
};

export const defaultWebdavSyncConfig: WebdavSyncConfig = {
    url: "",
    username: "",
    password: "",
    directory: "infinite-canvas",
    lastSyncedAt: "",
};

type ConfigStore = {
    config: AiConfig;
    webdav: WebdavSyncConfig;
    isConfigOpen: boolean;
    configTab: ConfigTabKey;
    shouldPromptContinue: boolean;
    updateConfig: <K extends keyof AiConfig>(key: K, value: AiConfig[K]) => void;
    updateWebdavConfig: <K extends keyof WebdavSyncConfig>(key: K, value: WebdavSyncConfig[K]) => void;
    isAiConfigReady: (config: AiConfig, model: string) => boolean;
    openConfigDialog: (shouldPromptContinue?: boolean, tab?: ConfigTabKey) => void;
    setConfigDialogOpen: (isOpen: boolean) => void;
    clearPromptContinue: () => void;
};

const VIDEO_KEYWORDS = ["video", "sora", "veo", "kling", "seedance", "wan", "hailuo", "minimax", "grok-imagine"];

export function boolConfig(value: string, fallback: boolean) {
    return value ? value === "true" : fallback;
}
const AUDIO_KEYWORDS = ["audio", "tts", "speech", "voice", "music", "sound"];
const IMAGE_KEYWORDS = ["seedream", "gpt-image", "image", "dall-e", "dalle", "imagen", "flux", "sdxl", "stable-diffusion", "midjourney"];

/** Best-effort default capability for a freshly fetched model name; user can override in the channel editor. */
export function guessCapability(name: string): ModelCapability {
    const value = name.toLowerCase();
    if (VIDEO_KEYWORDS.some((keyword) => value.includes(keyword))) return "video";
    if (AUDIO_KEYWORDS.some((keyword) => value.includes(keyword))) return "audio";
    if (IMAGE_KEYWORDS.some((keyword) => value.includes(keyword))) return "image";
    return "text";
}

function findChannelModel(config: AiConfig, value: string): { channel: ModelChannel; model: ChannelModel } | null {
    const decoded = decodeChannelModel(value);
    const name = decoded?.model || value;
    const channel = decoded ? config.channels.find((item) => item.id === decoded.channelId) : config.channels.find((item) => item.models.some((model) => model.name === name));
    const model = channel?.models.find((item) => item.name === name);
    return channel && model ? { channel, model } : null;
}

export function modelCapabilityOf(config: AiConfig, value: string): ModelCapability | undefined {
    return findChannelModel(config, value)?.model.capability;
}

export function modelMatchesCapability(config: AiConfig, value: string, capability?: ModelCapability) {
    if (!capability) return true;
    return modelCapabilityOf(config, value) === capability;
}

export function resolveModelForCapability(config: AiConfig, currentModel: string | undefined, capability: ModelCapability) {
    const defaultModel = capability === "image" ? config.imageModel : capability === "video" ? config.videoModel : capability === "audio" ? config.audioModel : config.textModel;
    const fallbackModel = capability === "image" ? defaultConfig.imageModel : capability === "video" ? defaultConfig.videoModel : capability === "audio" ? defaultConfig.audioModel : defaultConfig.textModel;
    if (currentModel && modelMatchesCapability(config, currentModel, capability)) return currentModel;
    if (defaultModel && modelMatchesCapability(config, defaultModel, capability)) return defaultModel;
    return fallbackModel;
}

export function selectableModelsByCapability(config: AiConfig, capability?: ModelCapability) {
    if (!capability) return config.models;
    return config.channels.flatMap((channel) => channel.models.filter((model) => model.capability === capability).map((model) => encodeChannelModel(channel.id, model.name)));
}

/** The user script (if any) attached to a model; empty string means use the system default call. */
export function resolveModelScript(config: AiConfig, value: string) {
    return findChannelModel(config, value)?.model.script?.trim() || "";
}

function isAiConfigReady(config: AiConfig, model: string) {
    const channel = resolveModelChannel(config, model);
    return Boolean(model.trim() && channel.baseUrl.trim() && channel.apiKey.trim());
}

export const useConfigStore = create<ConfigStore>()(
    persist(
        (set, get) => ({
            config: defaultConfig,
            webdav: defaultWebdavSyncConfig,
            isConfigOpen: false,
            configTab: "channels",
            shouldPromptContinue: false,
            updateConfig: (key, value) =>
                set((state) => ({
                    config: {
                        ...state.config,
                        [key]: value,
                    },
                })),
            updateWebdavConfig: (key, value) =>
                set((state) => ({
                    webdav: {
                        ...state.webdav,
                        [key]: value,
                    },
                })),
            isAiConfigReady: (config, model) => isAiConfigReady(config, model),
            openConfigDialog: (shouldPromptContinue = false, configTab = "channels") => set({ isConfigOpen: true, shouldPromptContinue, configTab }),
            setConfigDialogOpen: (isConfigOpen) => set({ isConfigOpen }),
            clearPromptContinue: () => set({ shouldPromptContinue: false }),
        }),
        {
            name: CONFIG_STORE_KEY,
            partialize: (state) => ({ config: state.config, webdav: state.webdav }),
            merge: (persisted, current) => {
                const persistedState = (persisted || {}) as Partial<ConfigStore>;
                const persistedConfig = (persistedState.config || {}) as Partial<AiConfig>;
                const persistedWebdav = (persistedState.webdav || {}) as Partial<WebdavSyncConfig>;
                const config = { ...defaultConfig, ...persistedConfig, baseUrl: migrateBaseUrl(persistedConfig.baseUrl) || defaultConfig.baseUrl };
                if (config.textModel === "default::gpt-5.5" || config.textModel === "gpt-5.5") {
                    config.textModel = defaultConfig.textModel;
                }
                if (config.videoModel === "default::seedance-2.0" || config.videoModel === "seedance-2.0") {
                    config.videoModel = defaultConfig.videoModel;
                }
                if (config.videoModel === "default::grok-imagine-video" || config.videoModel === "grok-imagine-video") {
                    config.videoModel = defaultConfig.videoModel;
                }
                config.channels = (config.channels || []).map((channel) => ({
                    ...channel,
                    baseUrl: migrateBaseUrl(channel.baseUrl) || defaultConfig.baseUrl,
                    models: (channel.models || []).map((model) =>
                        typeof model === "string"
                            ? { name: model === "grok-imagine-video" ? "seedance2.0-900-720p" : model, capability: guessCapability(model === "grok-imagine-video" ? "seedance2.0-900-720p" : model) }
                            : model.name === "grok-imagine-video"
                              ? { ...model, name: "seedance2.0-900-720p", capability: "video" as const }
                              : model,
                    ),
                }));
                if (!Array.isArray(persistedConfig.channels)) config.channels = [];
                const channels = normalizeChannels(config);
                // Configs saved before the AutoDL catalog was introduced can
                // contain only the old default model (for example
                // seedance2.0-900-720p). Keep user-defined channels intact,
                // but make the built-in/default channel discover all bundled
                // AutoDL workflows after an upgrade without requiring users
                // to clear localStorage manually.
                const catalogChannel = channels.find((channel) => channel.id === "default") || channels[0];
                if (catalogChannel) {
                    const catalogModels = defaultConfig.channels[0]?.models || [];
                    catalogChannel.models = normalizeChannelModels([...catalogChannel.models, ...catalogModels]);
                }
                const models = modelOptionsFromChannels(channels);
                return {
                    ...current,
                    webdav: { ...defaultWebdavSyncConfig, ...persistedWebdav },
                    config: {
                        ...config,
                        channelMode: "local",
                        apiFormat: normalizeApiFormat(config.apiFormat),
                        channels,
                        models,
                        imageModel: normalizeModelOptionValue(config.imageModel || config.model, channels),
                        videoModel: normalizeModelOptionValue(config.videoModel, channels),
                        textModel: normalizeModelOptionValue(config.textModel || config.model, channels),
                        audioModel: normalizeModelOptionValue(config.audioModel || defaultConfig.audioModel, channels),
                        audioVoice: config.audioVoice || defaultConfig.audioVoice,
                        audioFormat: config.audioFormat || defaultConfig.audioFormat,
                        audioSpeed: config.audioSpeed || defaultConfig.audioSpeed,
                        audioInstructions: config.audioInstructions || "",
                        reasoningEffort: config.reasoningEffort || "auto",
                        videoSeconds: config.videoSeconds || "6",
                        vquality: config.vquality || "720",
                        videoGenerateAudio: config.videoGenerateAudio || "true",
                        videoWatermark: config.videoWatermark || "false",
                        canvasImageCount: config.canvasImageCount || "3",
                    },
                };
            },
        },
    ),
);

export function useEffectiveConfig() {
    const config = useConfigStore((state) => state.config);
    return useMemo(() => ({ ...config, channelMode: "local" as const }), [config]);
}

/** Normalize a mixed list of raw model names or model objects into deduped ChannelModel entries. */
export function normalizeChannelModels(models: Array<string | ChannelModel> | undefined): ChannelModel[] {
    const seen = new Set<string>();
    const result: ChannelModel[] = [];
    for (const item of models || []) {
        const name = (typeof item === "string" ? item : item?.name || "").trim();
        if (!name || seen.has(name)) continue;
        seen.add(name);
        const capability = typeof item === "string" ? guessCapability(name) : item.capability || guessCapability(name);
        const script = typeof item === "string" ? undefined : item.script?.trim() || undefined;
        result.push({ name, capability, script });
    }
    return result;
}

export function createModelChannel(channel?: Partial<ModelChannel>): ModelChannel {
    const apiFormat = normalizeApiFormat(channel?.apiFormat);
    return {
        id: channel?.id?.trim() || nanoid(),
        name: channel?.name?.trim() || i18n.t("config.channels.newName"),
        baseUrl: channel?.baseUrl?.trim() || defaultBaseUrlForApiFormat(apiFormat),
        apiKey: channel?.apiKey || "",
        apiFormat,
        models: normalizeChannelModels(channel?.models),
    };
}

export function encodeChannelModel(channelId: string, model: string) {
    return `${channelId}${CHANNEL_MODEL_SEPARATOR}${model.trim()}`;
}

export function isChannelModelValue(value: string) {
    return value.includes(CHANNEL_MODEL_SEPARATOR);
}

export function decodeChannelModel(value: string) {
    const index = value.indexOf(CHANNEL_MODEL_SEPARATOR);
    if (index < 0) return null;
    return { channelId: value.slice(0, index), model: value.slice(index + CHANNEL_MODEL_SEPARATOR.length) };
}

export function modelOptionName(value: string) {
    return decodeChannelModel(value)?.model || value;
}

export function modelApiName(value: string) {
    const name = modelOptionName(value).trim();
    return MODEL_API_NAMES[name] || name;
}

export function modelDisplayName(value: string) {
    const name = modelOptionName(value).trim();
    return MODEL_DISPLAY_NAMES[name] || name;
}

export function modelOptionLabel(config: AiConfig, value: string) {
    const decoded = decodeChannelModel(value);
    const displayName = modelDisplayName(value);
    if (!decoded) return displayName;
    const channel = config.channels.find((item) => item.id === decoded.channelId);
    if (!channel) return displayName;
    return displayName + " (" + channel.name + ")";
    /*
    return channel ? `${displayName}（${channel.name}）` : displayName;
}

    */
}

export function modelOptionsFromChannels(channels: ModelChannel[]) {
    return uniqueModelOptions(channels.flatMap((channel) => channel.models.map((model) => encodeChannelModel(channel.id, model.name))));
}

export function normalizeModelOptionValue(value: string | undefined, channels: ModelChannel[]) {
    const model = (value || "").trim();
    if (!model) return "";
    const decoded = decodeChannelModel(model);
    if (decoded) {
        const channel = channels.find((item) => item.id === decoded.channelId);
        return channel && channel.models.some((item) => item.name === decoded.model) ? model : "";
    }
    const channel = channels.find((item) => item.models.some((entry) => entry.name === model)) || channels[0];
    return channel && channel.models.some((item) => item.name === model) ? encodeChannelModel(channel.id, model) : model;
}

export function resolveModelChannel(config: AiConfig, value: string) {
    const decoded = decodeChannelModel(value);
    const model = decoded?.model || value;
    const matched = decoded ? config.channels.find((channel) => channel.id === decoded.channelId) : config.channels.find((channel) => channel.models.some((item) => item.name === model));
    return matched || config.channels[0] || createModelChannel({ id: "default", name: i18n.t("config.channels.defaultName"), baseUrl: config.baseUrl, apiKey: config.apiKey, apiFormat: config.apiFormat, models: config.models.map(modelOptionName).map((name) => ({ name, capability: guessCapability(name) })) });
}

export function resolveModelRequestConfig(config: AiConfig, value: string) {
    const channel = resolveModelChannel(config, value);
    return {
        ...config,
        model: modelOptionName(value || config.model),
        baseUrl: channel.baseUrl,
        apiKey: channel.apiKey,
        apiFormat: channel.apiFormat,
    };
}

function normalizeChannels(config: AiConfig) {
    const persistedChannels = Array.isArray(config.channels) ? config.channels : [];
    const channels = persistedChannels.map((channel, index) =>
        createModelChannel({
            ...channel,
            id: channel.id || (index === 0 ? "default" : `channel-${index + 1}`),
            name: channel.name || (index === 0 ? i18n.t("config.channels.defaultName") : i18n.t("config.channels.indexedName", { index: index + 1 })),
            models: normalizeChannelModels(channel.models),
        }),
    );
    if (!channels.length) {
        channels.push(
            createModelChannel({
                id: "default",
                name: i18n.t("config.channels.defaultName"),
                baseUrl: config.baseUrl || defaultConfig.baseUrl,
                apiKey: config.apiKey || "",
                apiFormat: config.apiFormat || defaultConfig.apiFormat,
                models: normalizeChannelModels([config.model, config.imageModel, config.videoModel, config.textModel, config.audioModel].map(modelOptionName)),
            }),
        );
    }
    return channels;
}

export function defaultBaseUrlForApiFormat(apiFormat: ApiCallFormat) {
    if (apiFormat === "gemini") return GEMINI_BASE_URL;
    return OPENAI_BASE_URL;
}

function normalizeApiFormat(apiFormat: unknown): ApiCallFormat {
    return apiFormat === "gemini" ? apiFormat : "openai";
}

export function migrateBaseUrl(baseUrl: string | null | undefined) {
    const normalized = baseUrl?.trim().replace(/\/$/, "");
    if (!normalized) return baseUrl;
    try {
        const parsed = new URL(normalized);
        if (["localhost", "127.0.0.1", "0.0.0.0", "::1", "api.openai.com", "api.cc2.cx"].includes(parsed.hostname.toLowerCase())) return defaultOpenAiBaseUrl();
    } catch {
        // Keep malformed user input unchanged so the request layer can report it clearly.
    }
    return baseUrl;
}

function uniqueModelOptions(models: string[]) {
    return Array.from(new Set((models || []).map((model) => model.trim()).filter(Boolean)));
}

export function buildApiUrl(baseUrl: string, path: string) {
    const normalizedBaseUrl = baseUrl.trim().replace(/\/+$/, "");
    const lowerBaseUrl = normalizedBaseUrl.toLowerCase();
    const apiBaseUrl = lowerBaseUrl.endsWith("/v1") ? normalizedBaseUrl : `${normalizedBaseUrl}/v1`;
    return `${apiBaseUrl}${path}`;
}
